// ==================== INSIGHTS ====================
function showInsight(v){
    document.getElementById('insightTabs').innerHTML='<button class="filter-btn '+(v==='overview'?'active':'')+'" onclick="showInsight(\'overview\')">Overview</button><button class="filter-btn '+(v==='study'?'active':'')+'" onclick="showInsight(\'study\')">Study</button><button class="filter-btn '+(v==='discipline'?'active':'')+'" onclick="showInsight(\'discipline\')">Discipline</button><button class="filter-btn '+(v==='energy'?'active':'')+'" onclick="showInsight(\'energy\')">Energy</button><button class="filter-btn '+(v==='pomodoro'?'active':'')+'" onclick="showInsight(\'pomodoro\')">Pomodoro</button>';
    const time=arr(K.time),goals=arr(K.goals),disc=get(K.discipline)||{},protocol=get(K.protocol)||{};
    const content=document.getElementById('insightsContent');
    
    if(v==='overview'){
        const totalH=time.reduce((s,e)=>s+(parseFloat(e.duration)||0),0);
        const ws=new Date();ws.setDate(ws.getDate()-ws.getDay());
        const weekH=time.filter(e=>e.date>=fmtDate(ws)).reduce((s,e)=>s+(parseFloat(e.duration)||0),0);
        const cards = arr(K.flashcards);
        const contacts = arr(K.contacts);
        content.innerHTML=`
            <div class="grid grid-3" style="margin-bottom:16px;">
                <div class="stat"><div class="stat-value">${totalH.toFixed(0)}h</div><div class="stat-label">Total Hours</div></div>
                <div class="stat"><div class="stat-value">${weekH.toFixed(1)}h</div><div class="stat-label">This Week</div></div>
                <div class="stat"><div class="stat-value">${calcDisciplineStreak()}</div><div class="stat-label">Day Streak</div></div>
            </div>
            <div class="grid grid-4" style="margin-bottom:16px;">
                <div class="stat"><div class="stat-value">${goals.length}</div><div class="stat-label">Goals</div></div>
                <div class="stat"><div class="stat-value">${goals.filter(g=>g.completed).length}</div><div class="stat-label">Completed</div></div>
                <div class="stat"><div class="stat-value">${cards.length}</div><div class="stat-label">Flashcards</div></div>
                <div class="stat"><div class="stat-value">${contacts.length}</div><div class="stat-label">Contacts</div></div>
            </div>
        `;
    }else if(v==='study'){
        const studyH=time.filter(e=>e.category==='study').reduce((s,e)=>s+(parseFloat(e.duration)||0),0);
        const byDomain={};time.filter(e=>e.domain).forEach(e=>{byDomain[e.domain]=(byDomain[e.domain]||0)+(parseFloat(e.duration)||0);});
        content.innerHTML='<div class="stat" style="margin-bottom:16px;"><div class="stat-value">'+studyH.toFixed(1)+'h</div><div class="stat-label">Total Study</div></div>'+Object.entries(byDomain).sort((a,b)=>b[1]-a[1]).map(([d,h])=>'<div class="list-item"><div class="list-item-content"><div class="list-item-title">'+d+'</div></div><span style="color:var(--accent);font-weight:600;">'+h.toFixed(1)+'h</span></div>').join('');
    }else if(v==='discipline'){
        const last7=[];for(let i=6;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);last7.push(fmtDate(d));}
        const scores=last7.map(ds=>{const day=disc[ds]||{};return {date:ds,score:DISCIPLINES.reduce((s,x)=>s+(day[x.id]||0),0)};});
        const avg=scores.reduce((s,x)=>s+x.score,0)/7;
        content.innerHTML=`
            <div class="stat" style="margin-bottom:16px;"><div class="stat-value">${avg.toFixed(0)}/50</div><div class="stat-label">7-Day Average</div></div>
            ${scores.map(s=>`
                <div class="list-item">
                    <span style="min-width:80px;font-size:0.8rem;">${new Date(s.date+'T12:00').toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'})}</span>
                    <div style="flex:1;"><div class="progress" style="height:8px;"><div class="progress-fill" style="width:${(s.score/50)*100}%"></div></div></div>
                    <span style="min-width:40px;text-align:right;font-weight:600;color:var(--accent);">${s.score}</span>
                </div>
            `).join('')}
        `;
    }else if(v==='energy'){
        // Energy / Mood Correlation Analysis
        const last14=[];for(let i=13;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);last14.push(fmtDate(d));}
        const energyData = last14.map(ds => {
            const proto = protocol[ds];
            const dayDisc = disc[ds] || {};
            const dayHours = time.filter(t => t.date === ds).reduce((s, t) => s + (parseFloat(t.duration) || 0), 0);
            const discScore = DISCIPLINES.reduce((s, x) => s + (dayDisc[x.id] || 0), 0);
            return {
                date: ds,
                energy: proto?.energy || null,
                hours: dayHours,
                discipline: discScore
            };
        }).filter(d => d.energy !== null);
        
        // Calculate correlations
        const avgEnergy = energyData.length ? (energyData.reduce((s, d) => s + d.energy, 0) / energyData.length).toFixed(1) : '-';
        const highEnergyDays = energyData.filter(d => d.energy >= 7);
        const lowEnergyDays = energyData.filter(d => d.energy <= 4);
        const avgHighHours = highEnergyDays.length ? (highEnergyDays.reduce((s, d) => s + d.hours, 0) / highEnergyDays.length).toFixed(1) : '-';
        const avgLowHours = lowEnergyDays.length ? (lowEnergyDays.reduce((s, d) => s + d.hours, 0) / lowEnergyDays.length).toFixed(1) : '-';
        
        content.innerHTML = `
            <div class="grid grid-3" style="margin-bottom:16px;">
                <div class="stat"><div class="stat-value">${avgEnergy}</div><div class="stat-label">Avg Energy (14d)</div></div>
                <div class="stat"><div class="stat-value">${avgHighHours}h</div><div class="stat-label">High Energy Avg</div></div>
                <div class="stat"><div class="stat-value">${avgLowHours}h</div><div class="stat-label">Low Energy Avg</div></div>
            </div>
            <div style="margin-bottom:16px;">
                <div style="font-size:0.75rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:12px;">Energy vs Productivity (14 Days)</div>
                ${energyData.map(d => `
                    <div class="list-item" style="padding:8px 0;">
                        <span style="min-width:60px;font-size:0.75rem;">${new Date(d.date+'T12:00').toLocaleDateString('en-US',{weekday:'short'})}</span>
                        <span style="min-width:70px;font-weight:600;color:${d.energy >= 7 ? 'var(--success)' : d.energy <= 4 ? 'var(--danger)' : 'var(--warning)'};">⚡ ${d.energy}/10</span>
                        <div style="flex:1;display:flex;gap:8px;align-items:center;">
                            <div class="progress" style="flex:1;height:6px;"><div class="progress-fill" style="width:${Math.min(d.hours * 10, 100)}%;background:var(--accent);"></div></div>
                            <span style="font-size:0.75rem;color:var(--text-muted);min-width:35px;">${d.hours.toFixed(1)}h</span>
                        </div>
                        <span style="min-width:50px;text-align:right;font-size:0.8rem;color:${d.discipline >= 35 ? 'var(--success)' : 'var(--text-muted)'}">${d.discipline}/50</span>
                    </div>
                `).join('')}
            </div>
            <div class="card" style="background:var(--bg-tertiary);padding:14px;">
                <div style="font-weight:600;margin-bottom:8px;">💡 Insight</div>
                <div style="font-size:0.9rem;color:var(--text-secondary);">
                    ${avgHighHours !== '-' && avgLowHours !== '-' && parseFloat(avgHighHours) > parseFloat(avgLowHours) 
                        ? `You're ${((parseFloat(avgHighHours) / parseFloat(avgLowHours) - 1) * 100).toFixed(0)}% more productive on high-energy days. Protect your sleep and energy!` 
                        : 'Log more protocol data to see energy-productivity correlations.'}
                </div>
            </div>
        `;
    }else if(v==='pomodoro'){
        const stats = get(K.pomodoroStats) || {};
        const last7=[];for(let i=6;i>=0;i--){const d=new Date();d.setDate(d.getDate()-i);last7.push(fmtDate(d));}
        const weekTotal = last7.reduce((s, d) => s + (stats[d] || 0), 0);
        const todayCount = stats[today()] || 0;
        
        content.innerHTML = `
            <div class="grid grid-3" style="margin-bottom:16px;">
                <div class="stat"><div class="stat-value">${todayCount}</div><div class="stat-label">Today</div></div>
                <div class="stat"><div class="stat-value">${weekTotal}</div><div class="stat-label">This Week</div></div>
                <div class="stat"><div class="stat-value">${(weekTotal * 25 / 60).toFixed(1)}h</div><div class="stat-label">Focus Time</div></div>
            </div>
            <div style="font-size:0.75rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;margin-bottom:12px;">Last 7 Days</div>
            ${last7.map(d => `
                <div class="list-item">
                    <span style="min-width:80px;font-size:0.8rem;">${new Date(d+'T12:00').toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric'})}</span>
                    <div style="flex:1;display:flex;gap:4px;">
                        ${Array(stats[d] || 0).fill(0).map(() => '<div style="width:12px;height:12px;background:var(--accent);border-radius:3px;"></div>').join('')}
                        ${!stats[d] ? '<span style="color:var(--text-muted);font-size:0.8rem;">-</span>' : ''}
                    </div>
                    <span style="min-width:60px;text-align:right;font-weight:600;color:var(--accent);">${stats[d] || 0} 🍅</span>
                </div>
            `).join('')}
        `;
    }
}

