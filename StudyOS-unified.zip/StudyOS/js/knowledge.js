// ==================== KNOWLEDGE VAULT ====================
let editingKnowledgeId = null;
let knowledgeFilter = 'all';

function renderKnowledge() {
    const notes = arr(K.knowledge);
    document.getElementById('knowledgeFilters').innerHTML = `
        <button class="filter-btn ${knowledgeFilter==='all'?'active':''}" onclick="filterKnowledge('all',this)">All</button>
        <button class="filter-btn ${knowledgeFilter==='pmp'?'active':''}" onclick="filterKnowledge('pmp',this)">PMP</button>
        <button class="filter-btn ${knowledgeFilter==='mcmaster'?'active':''}" onclick="filterKnowledge('mcmaster',this)">McMaster</button>
        <button class="filter-btn ${knowledgeFilter==='smr'?'active':''}" onclick="filterKnowledge('smr',this)">SMR</button>
    `;
    const filtered = knowledgeFilter === 'all' ? notes : notes.filter(n => n.pathway === knowledgeFilter);
    const container = document.getElementById('knowledgeContainer');
    if (filtered.length === 0) {
        container.innerHTML = '<div class="empty" style="grid-column:1/-1;">No notes yet. Start building your knowledge vault.</div>';
        return;
    }
    container.innerHTML = filtered.sort((a,b) => (b.updated||b.created||'').localeCompare(a.updated||a.created||'')).map(n => `
        <div class="card" style="cursor:pointer;margin-bottom:0;" onclick="editKnowledge('${n.id}')">
            <div style="font-weight:600;margin-bottom:8px;">${esc(n.title)}</div>
            <div style="font-size:0.85rem;color:var(--text-secondary);display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden;margin-bottom:10px;">${esc(n.content)}</div>
            <div style="display:flex;flex-wrap:wrap;gap:6px;">
                ${n.pathway ? `<span class="badge badge-${n.pathway}">${n.pathway}</span>` : ''}
                ${(n.tags||[]).slice(0,3).map(t => `<span style="font-size:0.65rem;padding:2px 6px;background:var(--bg-tertiary);border-radius:4px;color:var(--text-muted);">${esc(t)}</span>`).join('')}
            </div>
        </div>
    `).join('');
}

function filterKnowledge(f, el) {
    knowledgeFilter = f;
    renderKnowledge();
}

function openKnowledgeModal() {
    editingKnowledgeId = null;
    document.getElementById('knowledgeTitle').value = '';
    document.getElementById('knowledgePathway').value = '';
    document.getElementById('knowledgeTags').value = '';
    document.getElementById('knowledgeContent').value = '';
    document.getElementById('knowledgeDeleteBtn').style.display = 'none';
    openModal('knowledgeModal');
}

function editKnowledge(id) {
    const n = arr(K.knowledge).find(x => x.id === id);
    if (!n) return;
    editingKnowledgeId = id;
    document.getElementById('knowledgeTitle').value = n.title || '';
    document.getElementById('knowledgePathway').value = n.pathway || '';
    document.getElementById('knowledgeTags').value = (n.tags || []).join(', ');
    document.getElementById('knowledgeContent').value = n.content || '';
    document.getElementById('knowledgeDeleteBtn').style.display = 'block';
    openModal('knowledgeModal');
}

function saveKnowledge() {
    const title = document.getElementById('knowledgeTitle').value.trim();
    const content = document.getElementById('knowledgeContent').value.trim();
    if (!title || !content) { toast('Title and content required'); return; }
    
    const notes = arr(K.knowledge);
    const tagsStr = document.getElementById('knowledgeTags').value.trim();
    const tags = tagsStr ? tagsStr.split(',').map(t => t.trim()).filter(t => t) : [];
    const pathway = document.getElementById('knowledgePathway').value || null;
    
    if (editingKnowledgeId) {
        const n = notes.find(x => x.id === editingKnowledgeId);
        if (n) {
            n.title = title;
            n.content = content;
            n.tags = tags;
            n.pathway = pathway;
            n.updated = today();
        }
    } else {
        notes.push({ id: uid(), title, content, tags, pathway, created: today() });
    }
    
    set(K.knowledge, notes);
    closeModal('knowledgeModal');
    renderKnowledge();
    toast('Saved!');
}

function deleteKnowledge() {
    if (!editingKnowledgeId || !confirm('Delete note?')) return;
    set(K.knowledge, arr(K.knowledge).filter(n => n.id !== editingKnowledgeId));
    closeModal('knowledgeModal');
    renderKnowledge();
    toast('Deleted');
}

