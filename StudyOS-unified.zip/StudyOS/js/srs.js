// ==================== SPACED REPETITION / FLASHCARDS ====================
let editingCardId = null;
let srsFilter = 'all';
let currentReviewCards = [];
let currentCardIndex = 0;
let cardFlipped = false;

// Spaced repetition intervals (in days)
const SRS_INTERVALS = {
    new: 0,
    hard: 1,
    medium: 3,
    easy: 7,
    mastered: 14
};

function renderFlashcards() {
    const cards = arr(K.flashcards);
    const now = new Date();
    const todayStr = today();
    
    // Calculate stats
    const dueNow = cards.filter(c => c.nextReview && c.nextReview <= todayStr).length;
    const dueToday = dueNow; // same for now
    const newCards = cards.filter(c => !c.nextReview || c.reviews === 0).length;
    
    document.getElementById('srsDueNow').textContent = dueNow;
    document.getElementById('srsDueToday').textContent = dueToday;
    document.getElementById('srsTotal').textContent = cards.length;
    
    // Calculate streak
    const reviewHistory = get(K.cardReviews) || {};
    let streak = 0;
    let checkDate = new Date();
    while (reviewHistory[fmtDate(checkDate)] && streak < 365) {
        streak++;
        checkDate.setDate(checkDate.getDate() - 1);
    }
    document.getElementById('srsStreak').textContent = streak;
    
    // Update review prompt
    const reviewArea = document.getElementById('srsStartReview');
    if (dueNow > 0) {
        document.getElementById('srsReviewPrompt').textContent = `You have ${dueNow} card${dueNow > 1 ? 's' : ''} to review!`;
        reviewArea.style.display = 'block';
    } else if (cards.length === 0) {
        document.getElementById('srsReviewPrompt').textContent = 'Create your first flashcard to get started';
        reviewArea.querySelector('button').textContent = '➕ Create Card';
        reviewArea.querySelector('button').onclick = () => openFlashcardModal();
    } else {
        document.getElementById('srsReviewPrompt').textContent = '🎉 All caught up! No cards due.';
        reviewArea.querySelector('button').style.display = 'none';
    }
    
    // Filters
    document.getElementById('srsFilters').innerHTML = `
        <button class="filter-btn ${srsFilter==='all'?'active':''}" onclick="srsFilter='all';renderFlashcards()">All (${cards.length})</button>
        <button class="filter-btn ${srsFilter==='due'?'active':''}" onclick="srsFilter='due';renderFlashcards()">Due (${dueNow})</button>
        <button class="filter-btn ${srsFilter==='new'?'active':''}" onclick="srsFilter='new';renderFlashcards()">New (${newCards})</button>
    `;
    
    // Filter cards
    let filtered = cards;
    if (srsFilter === 'due') filtered = cards.filter(c => c.nextReview && c.nextReview <= todayStr);
    if (srsFilter === 'new') filtered = cards.filter(c => !c.nextReview || c.reviews === 0);
    
    // Render list
    document.getElementById('flashcardsList').innerHTML = filtered.length ? filtered.map(card => `
        <div class="srs-queue-item" onclick="editFlashcard('${card.id}')">
            <div style="flex:1;min-width:0;">
                <div style="font-weight:500;margin-bottom:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${esc(card.question.substring(0, 60))}${card.question.length > 60 ? '...' : ''}</div>
                <div style="font-size:0.75rem;color:var(--text-muted);display:flex;gap:8px;">
                    <span>${card.category || 'general'}</span>
                    <span>•</span>
                    <span>${card.reviews || 0} reviews</span>
                </div>
            </div>
            ${card.nextReview && card.nextReview <= todayStr ? '<span class="due-badge due-now">Due</span>' : 
              card.nextReview ? `<span class="due-badge due-soon">${card.nextReview}</span>` : 
              '<span class="due-badge" style="background:rgba(34,197,94,0.15);color:var(--success);">New</span>'}
        </div>
    `).join('') : '<div class="empty">No flashcards yet. Create one to start learning!</div>';
}

function openFlashcardModal() {
    editingCardId = null;
    document.getElementById('flashcardModalTitle').textContent = 'New Flashcard';
    document.getElementById('cardQuestionInput').value = '';
    document.getElementById('cardAnswerInput').value = '';
    document.getElementById('cardCategory').value = 'pmp';
    document.getElementById('cardTags').value = '';
    document.getElementById('deleteCardBtn').style.display = 'none';
    openModal('flashcardModal');
}

function editFlashcard(id) {
    const cards = arr(K.flashcards);
    const card = cards.find(c => c.id === id);
    if (!card) return;
    
    editingCardId = id;
    document.getElementById('flashcardModalTitle').textContent = 'Edit Flashcard';
    document.getElementById('cardQuestionInput').value = card.question || '';
    document.getElementById('cardAnswerInput').value = card.answer || '';
    document.getElementById('cardCategory').value = card.category || 'general';
    document.getElementById('cardTags').value = (card.tags || []).join(', ');
    document.getElementById('deleteCardBtn').style.display = 'inline-block';
    openModal('flashcardModal');
}

function saveFlashcard() {
    const question = document.getElementById('cardQuestionInput').value.trim();
    const answer = document.getElementById('cardAnswerInput').value.trim();
    
    if (!question || !answer) {
        toast('Please fill in both question and answer');
        return;
    }
    
    const cards = arr(K.flashcards);
    const cardData = {
        question,
        answer,
        category: document.getElementById('cardCategory').value,
        tags: document.getElementById('cardTags').value.split(',').map(t => t.trim()).filter(t => t),
        updatedAt: new Date().toISOString()
    };
    
    if (editingCardId) {
        const idx = cards.findIndex(c => c.id === editingCardId);
        if (idx >= 0) cards[idx] = { ...cards[idx], ...cardData };
    } else {
        cards.push({
            id: uid(),
            ...cardData,
            createdAt: new Date().toISOString(),
            reviews: 0,
            nextReview: today(),
            interval: 0,
            easeFactor: 2.5
        });
    }
    
    set(K.flashcards, cards);
    closeModal('flashcardModal');
    renderFlashcards();
    toast(editingCardId ? 'Card updated!' : 'Card created!');
}

function deleteFlashcard() {
    if (!editingCardId || !confirm('Delete this flashcard?')) return;
    const cards = arr(K.flashcards).filter(c => c.id !== editingCardId);
    set(K.flashcards, cards);
    closeModal('flashcardModal');
    renderFlashcards();
    toast('Card deleted');
}

function startSRSReview() {
    const cards = arr(K.flashcards);
    const todayStr = today();
    currentReviewCards = cards.filter(c => !c.nextReview || c.nextReview <= todayStr);
    
    if (currentReviewCards.length === 0) {
        toast('No cards to review!');
        return;
    }
    
    // Shuffle cards
    currentReviewCards.sort(() => Math.random() - 0.5);
    currentCardIndex = 0;
    cardFlipped = false;
    
    document.getElementById('srsStartReview').style.display = 'none';
    document.getElementById('srsReviewArea').style.display = 'block';
    
    showCurrentCard();
}

function showCurrentCard() {
    if (currentCardIndex >= currentReviewCards.length) {
        // Review complete
        finishSRSReview();
        return;
    }
    
    const card = currentReviewCards[currentCardIndex];
    document.getElementById('cardMeta').textContent = `Card ${currentCardIndex + 1} of ${currentReviewCards.length}`;
    document.getElementById('cardQuestion').textContent = card.question;
    document.getElementById('cardAnswer').textContent = card.answer;
    
    document.getElementById('cardFront').style.display = 'block';
    document.getElementById('cardBack').style.display = 'none';
    document.getElementById('cardDifficulty').style.display = 'none';
    document.getElementById('currentFlashcard').classList.remove('flipped');
    cardFlipped = false;
}

function flipCard() {
    if (cardFlipped) return;
    cardFlipped = true;
    
    document.getElementById('cardFront').style.display = 'none';
    document.getElementById('cardBack').style.display = 'block';
    document.getElementById('cardDifficulty').style.display = 'flex';
    document.getElementById('currentFlashcard').classList.add('flipped');
}

function rateCard(difficulty) {
    const card = currentReviewCards[currentCardIndex];
    const cards = arr(K.flashcards);
    const idx = cards.findIndex(c => c.id === card.id);
    
    if (idx >= 0) {
        // SM-2 inspired algorithm (simplified)
        let interval = cards[idx].interval || 0;
        let easeFactor = cards[idx].easeFactor || 2.5;
        
        if (difficulty === 'easy') {
            interval = Math.max(interval * easeFactor, 7);
            easeFactor = Math.min(easeFactor + 0.1, 3.0);
        } else if (difficulty === 'medium') {
            interval = Math.max(interval * 1.5, 3);
        } else { // hard
            interval = 1;
            easeFactor = Math.max(easeFactor - 0.2, 1.3);
        }
        
        const nextDate = new Date();
        nextDate.setDate(nextDate.getDate() + Math.round(interval));
        
        cards[idx].reviews = (cards[idx].reviews || 0) + 1;
        cards[idx].interval = interval;
        cards[idx].easeFactor = easeFactor;
        cards[idx].nextReview = fmtDate(nextDate);
        cards[idx].lastReview = today();
        
        set(K.flashcards, cards);
    }
    
    // Log review for streak tracking
    const reviewHistory = get(K.cardReviews) || {};
    reviewHistory[today()] = (reviewHistory[today()] || 0) + 1;
    set(K.cardReviews, reviewHistory);
    
    currentCardIndex++;
    showCurrentCard();
}

function finishSRSReview() {
    document.getElementById('srsReviewArea').style.display = 'none';
    document.getElementById('srsStartReview').style.display = 'block';
    toast('🎉 Review session complete!');
    renderFlashcards();
}

