// ==================== PMP 49 PROCESSES ====================
const PMP_KNOWLEDGE_AREAS = [
    { id: 'integration', name: 'Integration', color: '#8b5cf6', processes: [
        { num: '4.1', name: 'Develop Project Charter' },
        { num: '4.2', name: 'Develop Project Management Plan' },
        { num: '4.3', name: 'Direct and Manage Project Work' },
        { num: '4.4', name: 'Manage Project Knowledge' },
        { num: '4.5', name: 'Monitor and Control Project Work' },
        { num: '4.6', name: 'Perform Integrated Change Control' },
        { num: '4.7', name: 'Close Project or Phase' }
    ]},
    { id: 'scope', name: 'Scope', color: '#3b82f6', processes: [
        { num: '5.1', name: 'Plan Scope Management' },
        { num: '5.2', name: 'Collect Requirements' },
        { num: '5.3', name: 'Define Scope' },
        { num: '5.4', name: 'Create WBS' },
        { num: '5.5', name: 'Validate Scope' },
        { num: '5.6', name: 'Control Scope' }
    ]},
    { id: 'schedule', name: 'Schedule', color: '#06b6d4', processes: [
        { num: '6.1', name: 'Plan Schedule Management' },
        { num: '6.2', name: 'Define Activities' },
        { num: '6.3', name: 'Sequence Activities' },
        { num: '6.4', name: 'Estimate Activity Durations' },
        { num: '6.5', name: 'Develop Schedule' },
        { num: '6.6', name: 'Control Schedule' }
    ]},
    { id: 'cost', name: 'Cost', color: '#10b981', processes: [
        { num: '7.1', name: 'Plan Cost Management' },
        { num: '7.2', name: 'Estimate Costs' },
        { num: '7.3', name: 'Determine Budget' },
        { num: '7.4', name: 'Control Costs' }
    ]},
    { id: 'quality', name: 'Quality', color: '#22c55e', processes: [
        { num: '8.1', name: 'Plan Quality Management' },
        { num: '8.2', name: 'Manage Quality' },
        { num: '8.3', name: 'Control Quality' }
    ]},
    { id: 'resource', name: 'Resource', color: '#84cc16', processes: [
        { num: '9.1', name: 'Plan Resource Management' },
        { num: '9.2', name: 'Estimate Activity Resources' },
        { num: '9.3', name: 'Acquire Resources' },
        { num: '9.4', name: 'Develop Team' },
        { num: '9.5', name: 'Manage Team' },
        { num: '9.6', name: 'Control Resources' }
    ]},
    { id: 'communications', name: 'Comms', color: '#eab308', processes: [
        { num: '10.1', name: 'Plan Communications Management' },
        { num: '10.2', name: 'Manage Communications' },
        { num: '10.3', name: 'Monitor Communications' }
    ]},
    { id: 'risk', name: 'Risk', color: '#f97316', processes: [
        { num: '11.1', name: 'Plan Risk Management' },
        { num: '11.2', name: 'Identify Risks' },
        { num: '11.3', name: 'Perform Qualitative Risk Analysis' },
        { num: '11.4', name: 'Perform Quantitative Risk Analysis' },
        { num: '11.5', name: 'Plan Risk Responses' },
        { num: '11.6', name: 'Implement Risk Responses' },
        { num: '11.7', name: 'Monitor Risks' }
    ]},
    { id: 'procurement', name: 'Procurement', color: '#ef4444', processes: [
        { num: '12.1', name: 'Plan Procurement Management' },
        { num: '12.2', name: 'Conduct Procurements' },
        { num: '12.3', name: 'Control Procurements' }
    ]},
    { id: 'stakeholder', name: 'Stakeholder', color: '#ec4899', processes: [
        { num: '13.1', name: 'Identify Stakeholders' },
        { num: '13.2', name: 'Plan Stakeholder Engagement' },
        { num: '13.3', name: 'Manage Stakeholder Engagement' },
        { num: '13.4', name: 'Monitor Stakeholder Engagement' }
    ]}
];

// ==================== WISDOM & PRINCIPLES ====================
const WISDOM = [
    { quote: "The successful warrior is the average man, with laser-like focus.", source: "Bruce Lee" },
    { quote: "We are what we repeatedly do. Excellence is not an act, but a habit.", source: "Aristotle" },
    { quote: "The impediment to action advances action. What stands in the way becomes the way.", source: "Marcus Aurelius" },
    { quote: "Discipline equals freedom.", source: "Jocko Willink" },
    { quote: "The best time to plant a tree was 20 years ago. The second best time is now.", source: "Chinese Proverb" },
    { quote: "Hard choices, easy life. Easy choices, hard life.", source: "Jerzy Gregorek" },
    { quote: "You do not rise to the level of your goals. You fall to the level of your systems.", source: "James Clear" },
    { quote: "The man who moves a mountain begins by carrying away small stones.", source: "Confucius" },
    { quote: "Be not afraid of going slowly, be afraid only of standing still.", source: "Chinese Proverb" },
    { quote: "First, master the fundamentals.", source: "Larry Bird" },
    { quote: "A project manager's job is not to know everything, but to know who knows.", source: "Construction PM Wisdom" },
    { quote: "In nuclear, there are no small mistakes. Attention to detail is not optional.", source: "Nuclear Industry Principle" },
    { quote: "Schedule drives budget. Understand the schedule, control the project.", source: "Construction Management" },
    { quote: "The amateur practices until they get it right. The professional practices until they can't get it wrong.", source: "Unknown" },
    { quote: "Think in decades. Act in days.", source: "Shreyas Doshi" }
];

const TIPS = {
    dashboard: [
        { type: 'info', title: 'Morning Routine', text: 'Start each day with the Protocol. It takes 5 minutes and sets your direction.' },
        { type: 'info', title: 'Compound Effect', text: '1% better daily = 37x better in a year. Small consistent actions beat sporadic big efforts.' }
    ],
    protocol: [
        { type: 'info', title: 'Why This Matters', text: 'The morning sets the trajectory. Top performers have non-negotiable morning routines.' },
        { type: 'success', title: 'Your Strength', text: 'Deliberative (#1): Use this time to think carefully about what truly matters today.' }
    ],
    discipline: [
        { type: 'info', title: 'The Scorecard', text: 'Rate yourself honestly. The goal isn\'t perfection—it\'s awareness and gradual improvement.' },
        { type: 'warning', title: 'Consistency > Intensity', text: 'A 70% day every day beats a 100% day once a week.' }
    ],
    learn: [
        { type: 'info', title: 'Active Recall', text: 'Don\'t just read. Test yourself. Write from memory. Explain concepts out loud.' },
        { type: 'info', title: 'Spaced Repetition', text: 'Review material at increasing intervals: 1 day, 3 days, 1 week, 2 weeks, 1 month.' }
    ],
    goals: [
        { type: 'info', title: 'Break It Down', text: 'If a goal feels overwhelming, it\'s not broken down enough. Add more milestones.' },
        { type: 'success', title: 'Your Strength', text: 'Analytical (#2): Use this to identify the critical path to each goal.' }
    ],
    tasks: [
        { type: 'info', title: 'Eat the Frog', text: 'Do your most important (often hardest) task first when energy is highest.' },
        { type: 'warning', title: 'Urgent vs Important', text: 'Important tasks build your future. Urgent tasks manage the present. Prioritize important.' }
    ],
    tracker: [
        { type: 'info', title: 'What Gets Measured', text: 'Tracking time reveals truth. You\'ll discover where hours actually go.' },
        { type: 'info', title: 'Deep Work Target', text: 'Aim for 3-4 hours of focused study daily. Quality beats quantity.' }
    ],
    habits: [
        { type: 'info', title: 'Habit Stacking', text: 'Attach new habits to existing ones: "After I [CURRENT HABIT], I will [NEW HABIT]."' },
        { type: 'info', title: 'Never Miss Twice', text: 'Missing once is an accident. Missing twice is the start of a new (bad) habit.' }
    ],
    journal: [
        { type: 'info', title: 'Reflection Compounds', text: 'Weekly reviews are where real learning happens. Patterns become visible.' },
        { type: 'success', title: 'Your Strength', text: 'Context (#4): Use journaling to see how past patterns inform future decisions.' }
    ]
};

// ==================== DISCIPLINE SYSTEM ====================
const DISCIPLINES = [
    { id: 'wake', name: 'Wake on time', desc: 'Started day at planned time', max: 10 },
    { id: 'protocol', name: 'Morning Protocol', desc: 'Completed morning routine', max: 10 },
    { id: 'focus', name: 'Deep Work', desc: '3+ hours focused study/work', max: 10 },
    { id: 'learn', name: 'Learning', desc: 'Studied something new', max: 10 },
    { id: 'health', name: 'Health', desc: 'Exercise, nutrition, sleep', max: 10 }
];

// ==================== LEARNING PATHWAYS ====================
const PATHWAYS = {
    pmp: {
        name: 'PMP Certification',
        desc: 'Project Management Professional - PMI',
        modules: [
            { id: 'p1', name: 'Integration Management', topics: ['Project charter', 'Project plan', 'Change control', 'Close project'], hours: 15 },
            { id: 'p2', name: 'Scope Management', topics: ['Requirements', 'WBS', 'Scope control'], hours: 12 },
            { id: 'p3', name: 'Schedule Management', topics: ['Activity sequencing', 'CPM', 'Schedule compression', 'Gantt charts'], hours: 15 },
            { id: 'p4', name: 'Cost Management', topics: ['Estimating', 'Budgeting', 'Earned Value Management'], hours: 15 },
            { id: 'p5', name: 'Quality Management', topics: ['Quality planning', 'QA/QC', 'Continuous improvement'], hours: 10 },
            { id: 'p6', name: 'Resource Management', topics: ['Team development', 'RACI', 'Conflict resolution'], hours: 12 },
            { id: 'p7', name: 'Communications', topics: ['Communication planning', 'Stakeholder engagement', 'Reporting'], hours: 8 },
            { id: 'p8', name: 'Risk Management', topics: ['Risk identification', 'Qualitative/Quantitative analysis', 'Response planning'], hours: 15 },
            { id: 'p9', name: 'Procurement', topics: ['Contract types', 'Procurement process', 'Vendor management'], hours: 10 },
            { id: 'p10', name: 'Stakeholder Management', topics: ['Stakeholder analysis', 'Engagement strategies'], hours: 8 }
        ]
    },
    mcmaster: {
        name: 'McMaster BTech Prep',
        desc: 'Civil Engineering Infrastructure Technology',
        modules: [
            { id: 'm1', name: 'Mathematics Review', topics: ['Calculus', 'Linear algebra', 'Statistics'], hours: 40 },
            { id: 'm2', name: 'Structures Fundamentals', topics: ['Statics', 'Strength of materials', 'Structural analysis'], hours: 30 },
            { id: 'm3', name: 'Geotechnical Basics', topics: ['Soil mechanics', 'Foundation design'], hours: 20 },
            { id: 'm4', name: 'Construction Methods', topics: ['Heavy civil', 'Infrastructure', 'Sustainable construction'], hours: 25 }
        ]
    },
    smr: {
        name: 'SMR Specialization',
        desc: 'Small Modular Reactor Construction',
        modules: [
            { id: 's1', name: 'Nuclear Industry Overview', topics: ['Regulatory framework', 'CNSC', 'Safety culture'], hours: 15 },
            { id: 's2', name: 'Nuclear-Grade QA/QC', topics: ['CSA N299', 'Quality programs', 'Documentation'], hours: 20 },
            { id: 's3', name: 'Modular Construction', topics: ['Off-site fabrication', 'Heavy lift logistics', 'Sequencing'], hours: 15 },
            { id: 's4', name: 'Nuclear Concrete', topics: ['Specifications', 'Placement', 'Testing requirements'], hours: 15 },
            { id: 's5', name: 'Project Controls', topics: ['EVM for nuclear', 'Schedule risk analysis', 'Change management'], hours: 20 }
        ]
    }
};

